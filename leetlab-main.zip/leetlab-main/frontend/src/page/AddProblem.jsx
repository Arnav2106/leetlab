import React from 'react'
import CreateProblemForm from '../components/CreateProblemForm'

const AddProblem = () => {
  return (
    <div>
      <CreateProblemForm/>
    </div>
  )
}

export default AddProblem